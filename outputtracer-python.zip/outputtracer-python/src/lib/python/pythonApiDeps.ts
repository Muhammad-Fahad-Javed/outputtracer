// INTEGRATION POINT — connect these to your existing auth and rate limiting.
//
// I could not inspect your repo (src/lib/rateLimit.ts, your Supabase auth
// helpers), so this file ships FAIL-CLOSED: until you wire it, both Python
// routes answer 503 "disabled". Nothing here weakens existing protections.
import { PythonSystemError } from "./pythonTypes";

export interface PythonApiDeps {
  /** Return a stable user id (<= 64 chars) or throw PythonSystemError("unauthorized"). */
  authenticate(req: Request): Promise<{ userId: string }>;
  /** Throw PythonSystemError("rate_limited") when the caller is over budget. */
  rateLimit(key: string, bucket: "python-run" | "python-trace"): Promise<void>;
}

let deps: PythonApiDeps | null = null;

/** Call once at startup (or edit the default below) to enable the routes. */
export function configurePythonApi(d: PythonApiDeps): void {
  deps = d;
}

export function getPythonApiDeps(): PythonApiDeps {
  if (!deps) throw new PythonSystemError("disabled");
  return deps;
}

/*
 * Example wiring (ADAPT to your real helpers):
 *
 *   import { createClient } from "@/lib/supabase/server";
 *   import { rateLimit } from "@/lib/rateLimit";
 *
 *   configurePythonApi({
 *     async authenticate() {
 *       const supabase = await createClient();
 *       const { data } = await supabase.auth.getUser();
 *       if (!data.user) throw new PythonSystemError("unauthorized");
 *       return { userId: data.user.id };
 *     },
 *     async rateLimit(key, bucket) {
 *       const ok = await rateLimit(`${bucket}:${key}`, { limit: 20, windowMs: 60_000 });
 *       if (!ok) throw new PythonSystemError("rate_limited");
 *     },
 *   });
 *
 * If your rate limiter is in-memory and you run several instances, use a
 * shared store (Redis/Postgres) — the per-instance counter is not enough.
 */
