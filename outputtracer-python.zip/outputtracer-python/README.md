# OutputTracer — Python 3 support (drop-in package)

**Read this first: what this package is and is not.**

This was built **without access to the OutputTracer repository**. The workspace was empty, so none of the existing files (`cppRunner.ts`, `rateLimit.ts`, the editor, the classroom code, `0003_learn_platform.sql`, …) were inspected. Everything here is therefore **self-contained and un-integrated**. It has not been built or run inside your Next.js app, and the C++/Assembly regression checks could not be performed.

Start with `docs/INTEGRATION_CHECKLIST.md`.

## What is included and how it was verified

| Part | Files | Verified here |
|---|---|---|
| In-sandbox run worker | `sandbox-worker/py/run_worker.py` | Unit tests (real subprocess) ✅ |
| In-sandbox step tracer | `sandbox-worker/py/trace_worker.py` | Unit tests (real subprocess) ✅ |
| Sandbox worker service (only component that calls Docker) | `sandbox-worker/server.mjs`, `dockerExec.mjs` | Node tests with a fake Docker ✅ |
| Sandbox image | `sandbox-worker/Dockerfile.sandbox` | **Not built** (no Docker daemon available) ❌ |
| Adversarial container checks | `sandbox-worker/tests/security/run_security_checks.sh` | **Not run** ❌ (syntax-checked only) |
| TS contracts, client, runner, tracer | `src/lib/python/*.ts` | Vitest + `tsc --noEmit` ✅ |
| API routes + pipeline | `src/app/api/python/**`, `pythonRoute.ts` | Vitest (calling handlers directly) ✅; **not run inside Next.js** |
| Auth + rate-limit hooks | `pythonApiDeps.ts` | **Ships fail-closed (503) until you wire it** |
| UI: trace panel, hook, starter, CSS | `src/components/python/*` | Type-checked only; **not rendered or tested in a browser** |
| Migration | `supabase/migrations/0012_python_language_support.sql` | **Not run against any database** |
| Curriculum content | `curriculum/python-curriculum.json` | Reference solutions pass all 15 questions' tests ✅; **not seeded** |
| Docs | `docs/*` | — |

Test commands (after `npm install`): `npm run test:ts`, `npm run test:node`, `npm run test:py`, `npm run typecheck`.

Last run: 36 Python tests, 16 Node tests and 33 Vitest tests passed, and `tsc --noEmit` was clean.

## Not done (needs your repo)

- Editor language selector, Monaco mode, `.py` file handling, project save/open
- Classroom assignment/submission language support and dashboards
- Existing-table constraint changes (the migration only *reports* constraints that may block `python`)
- Curriculum seeding SQL (content is provided as JSON)
- `npm run build`, local app smoke test, C++/Assembly regression run
- Any deployment; nothing was deployed and no database was touched

## Layout

```
sandbox-worker/   Node service + Dockerfile + Python workers + tests (deploy on a private host)
src/lib/python/   Types, client, runner, tracer, route pipeline, auth hooks, tests
src/app/api/python/            POST /api/python, POST /api/python/trace
src/components/python/         Trace panel, hook, starter template
supabase/migrations/           0012 (draft, defensive)
curriculum/       Topics + 15 practice questions (data)
docs/             Architecture, security, deployment, integration checklist
```
