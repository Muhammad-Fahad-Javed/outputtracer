# Architecture

```
Browser ──► Next.js API route ──► (HTTP + bearer token) ──► Sandbox worker service ──► docker run (one fresh container per run)
            /api/python                                      sandbox-worker/server.mjs     python3 -I run_worker.py | trace_worker.py
            /api/python/trace
```

Next.js **never** runs Python or Docker. Only the worker service talks to Docker, so the web process doesn't need access to the Docker socket.

## Request flow

1. Route: `getPythonApiDeps()` → authenticate → rate limit → reserve per-user in-flight slot (synchronously) → bounded body read (cap enforced while streaming) → validate.
2. `pythonSandboxClient`: refuses unless `PYTHON_EXECUTION_ENABLED=true`, URL set and token ≥ 32 chars; calls the worker with a bearer token and timeout.
3. Worker: auth (timing-safe) → validate → readiness check (Docker + image) → global concurrency gate + bounded queue + per-client cap → `docker run` with the code sent on **stdin** (no host mounts at all).
4. Deadline and output cap are enforced by the worker **outside** the container (`docker rm -f`).
5. Results are mapped to the contract in `pythonTypes.ts`.

## HTTP contract

* Transport/system failure → non-200 + `{ ok:false, error:{ code, message } }` with fixed public messages.
* Program outcome (including errors, timeouts, limits) → **HTTP 200** + `{ ok:true, result }` where `result.status` says what happened and `result.success` is true only for status `ok` + exit 0.

| Run status | Meaning |
|---|---|
| ok / nonzero_exit | exit 0 / program called `sys.exit(n)`, n≠0 |
| runtime_error / syntax_error | uncaught exception / compile error |
| timeout / output_limit | killed by worker deadline / output cap |
| resource_limit | container killed (exit 137, most likely memory limit) |

System codes: `invalid_request` 400, `source_too_large` 413, `input_too_large` 413, `unauthorized` 401, `rate_limited` 429, `busy` 429, `disabled` 503, `sandbox_unavailable` 503, `runtime_unavailable` 503, `internal_error` 500.

## Tracer contract (`trace_worker.py`)

* **Events:** `call` (function entry, args visible), `line` (BEFORE the line executes), `return` (carries `returnValue`), `exception` (raised in / propagating through a user frame). The module-level call is skipped (it has no source line). Steps are numbered from 0; lines are 1-based.
* **stdout is incremental:** each step's `stdout` is only what was printed since the previous step. Output after the last step is `trailingStdout`. The UI reconstructs "output so far" by summing (see `usePythonTrace.ts`).
* **Serialization:** only exact builtin types are walked (`None, bool, int, float, str, list, tuple, dict, set, frozenset`). Subclasses and user objects become `{t:"object", kind}`; no `repr`/`str`/property access runs on user objects. Bounds: depth 4, 30 items, 200 chars, 40 vars/frame, 30 stack frames. Circular refs → `ref`; NaN/Inf/huge ints are tagged.
* **Limits:** at the step cap or response-size cap the worker writes the result and calls `os._exit(0)`, so user code can't catch it with `except:`.
* **Determinism:** sets are emitted in canonical order and `PYTHONHASHSEED=0` is set. This holds for deterministic programs only; time, randomness, threads and external input are not deterministic.
* **Stepping backward/forward** is index arithmetic over the recorded steps in the browser; it never re-runs the program.
* **Trust:** the trace JSON is produced in the same process as the user's code, so it is **forgeable**. The Next.js side rebuilds every field from an allowlist with hard caps (`pythonTracer.ts`), and never trusts indices, counts or types.

## Known limits of the design

* Interactive stdin during a running program is **not** implemented: stdin is supplied up front. A managed interactive session would need a long-lived container, WebSocket, per-session auth, idle timeouts and cleanup, so it was deliberately not faked.
* Only the Python standard library is available; no pip packages and no network.
* Per-user in-flight limiting in the route is per Next.js instance; the worker's per-client cap is the cross-instance backstop.
