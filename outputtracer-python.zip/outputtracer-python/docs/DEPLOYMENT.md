# Deployment (nothing here was executed against your infrastructure)

Do **not** enable public Python execution until the security checks pass on the real host. If isolation cannot be provided, leave `PYTHON_EXECUTION_ENABLED` unset: the routes then return 503 `disabled`.

## 1. Sandbox host (separate VM recommended)

* Docker Engine ≥ 24 (or rootless Docker); optionally gVisor (`runsc`) registered as a Docker runtime.
* Verify cgroup limits work: `docker info` should show no "No memory limit support / No swap limit support" warnings.
* Build the image: `cd sandbox-worker && docker build -f Dockerfile.sandbox -t outputtracer-python-sandbox:latest .`
* Run the security script on this VM: `IMAGE=outputtracer-python-sandbox:latest ./tests/security/run_security_checks.sh`. All checks must pass.
* Run the worker (Node ≥ 20) as an unprivileged user in the `docker` group: `node sandbox-worker/server.mjs` under systemd.
* Bind to a private interface; firewall port 8787 to the app server only. Do not expose it through Nginx.

Worker env vars:

| Var | Default | Notes |
|---|---|---|
| `SANDBOX_TOKEN` | — | **required**, ≥ 32 chars; worker refuses to start without it |
| `SANDBOX_HOST` / `SANDBOX_PORT` | 127.0.0.1 / 8787 | use a private IP if the app is on another host |
| `SANDBOX_IMAGE` | `outputtracer-python-sandbox:latest` | |
| `SANDBOX_RUNTIME` | (empty) | e.g. `runsc` |
| `SANDBOX_MAX_CONCURRENCY` / `SANDBOX_MAX_QUEUE` | 2 / 8 | size to host RAM: concurrency × 128 MiB + headroom |
| `SANDBOX_MEMORY_MIB`, `SANDBOX_CPUS`, `SANDBOX_PIDS` | 128, 0.5, 64 | |
| `SANDBOX_TIMEOUT_MS` / `SANDBOX_TRACE_TIMEOUT_MS` | 5000 / 10000 | |

Health check: `GET /health` with the bearer token → 200 `{ok:true}` or 503 with a reason. Logs: stdout/stderr of the service (no user code is logged by this package). Add your own metrics on `active` / `queued` from `/health`.

Example systemd unit:

```
[Service]
User=pysandbox
EnvironmentFile=/etc/outputtracer/sandbox.env
ExecStart=/usr/bin/node /opt/outputtracer/sandbox-worker/server.mjs
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
```

## 2. App server (Next.js)

Add (see `.env.example`): `PYTHON_EXECUTION_ENABLED=true`, `PYTHON_SANDBOX_URL=http://<private-ip>:8787`, `PYTHON_SANDBOX_TOKEN=<same secret>`. Store the token in your secret manager, never in the repo or in client-exposed env vars (no `NEXT_PUBLIC_`).

Wire `configurePythonApi` (see `pythonApiDeps.ts`) to your Supabase auth and `rateLimit.ts`. If you run more than one app instance, the rate limiter needs a shared store.

Nginx: no new routes required (`/api/python*` is handled by Next.js). Ensure your `client_max_body_size` is ≥ 128k and proxy read timeout ≥ 20 s for the trace route.

## 3. Database

1. Review `supabase/migrations/0012_python_language_support.sql` against your real schema.
2. Apply to a **dev branch** first; read the NOTICE output (skipped steps, constraints to widen).
3. Widen any reported CHECK constraints deliberately (templates in the file).
4. Seed `curriculum/python-curriculum.json` with idempotent upserts keyed on the stable IDs; never touch progress tables.
5. Only then apply to production, with explicit sign-off and a fresh backup.

Rollback: the migration is additive. To roll back, set the Python row's `published=false` (or delete that one row if nothing references it) and restore any constraint you widened to its previous definition. User data is not modified.

## 4. Production smoke test (after enabling)

1. `GET /health` on the worker → `ok:true`.
2. Signed-in `POST /api/python` with `print(1+1)` → `result.stdout == "2\n"`, `success:true`.
3. `while True: pass` → `status:"timeout"` in ≈ 5 s, and `docker ps` shows no leftover `otpy-*` container.
4. `import socket; socket.create_connection(("1.1.1.1",53),2)` → runtime_error.
5. `POST /api/python/trace` on a 5-line loop → steps present; stepping in the UI makes no further network calls.
6. Unauthenticated call → 401; a burst of requests → 429.
7. Re-run your C++ and Assembly smoke tests.
