# Security model

## Isolation boundary

The boundary is the **Docker container** created per run (flags in `buildDockerArgs`, unit-tested for presence):

`--network none` · `--read-only` + `noexec` tmpfs `/tmp` (8 MiB) · `--cap-drop ALL` · `no-new-privileges` · non-root uid 10001 · `--memory/--memory-swap 128m` · `--cpus 0.5` · `--pids-limit 64` · `nofile/nproc/fsize` ulimits · `--ipc none` · no host mounts, no Docker socket, no environment secrets · fresh container per run, removed on exit.

Python-level tricks (restricted builtins, `settrace` tricks) are **not** part of the boundary. A timeout alone is not a boundary: the worker removes the container from outside.

## What is verified vs intended

| Claim | Status |
|---|---|
| The right isolation flags are present in the command | **Verified** (unit test) |
| Deadline / output-cap kill is triggered outside the container | **Verified with a fake Docker** (unit test) |
| Worker fails closed when Docker/image is missing; no host fallback | **Verified** (unit test) |
| Limits are actually enforced by a real Docker daemon | **Not verified** here (no daemon). Run `sandbox-worker/tests/security/run_security_checks.sh` on a disposable VM |
| Memory limit works | Only if the host kernel has cgroup memory accounting and swap limits enabled; check `docker info` for warnings |
| No outbound network | Intended via `--network none`; verified only by the script above |

## Residual risks (be honest with yourself about these)

1. **Shared kernel.** Plain Docker is not a hard boundary against kernel exploits. For untrusted public users prefer gVisor (`SANDBOX_RUNTIME=runsc`) or Kata/Firecracker, and run the worker on a dedicated VM with nothing else on it.
2. **The worker host has Docker access** (equivalent to root on that host). Do not co-locate it with the web app, database credentials or secrets. Keep it on a private interface, firewalled to the app server only.
3. **DoS.** Concurrency, queue, per-client caps, CPU/memory/pids caps and timeouts reduce, not eliminate, abuse. CPU-time per run is bounded by the wall-clock deadline × `--cpus`. Keep the app-level rate limit strict.
4. **Forged trace output.** Handled by allowlist sanitising on the Next.js side; a user can only fake their *own* trace.
5. **stderr / traceback text** is user-influenced content. Render as text only (the provided React panel does).
6. **Bearer token** to the worker is a single shared secret: rotate it, keep ≥ 32 random bytes, and prefer mTLS or a private network.
7. **Image supply chain.** Pin `python:3.12-slim` by digest and rebuild regularly for security patches.
8. **Hidden tests / grading** are not implemented in this package; when you add them, run them only server-side and never return expected outputs to students.

Nothing in this package should be described as "secure" until the checks above have been run on the real deployment.
