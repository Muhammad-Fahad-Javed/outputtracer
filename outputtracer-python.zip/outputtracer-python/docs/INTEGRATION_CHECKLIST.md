# Integration checklist (the work that needs your repo)

Do these on a branch. After each step run your existing tests and confirm C++/Assembly still work.

## 0. Audit (I could not do this)
- [ ] `git status`, current branch, package manager; confirm Next.js version (routes use the Web `Request`/`Response` API and `export const runtime = "nodejs"`).
- [ ] Read `src/lib/cppRunner.ts`, `src/lib/sandbox.ts`, `src/lib/runGate.ts`, `src/lib/rateLimit.ts`: match error shapes/naming where it makes sense. Do **not** reuse a C++ wrapper for Python unless it provides the isolation in `docs/SECURITY.md`.
- [ ] `grep -rn "cpp\|asm\|assembly"` for language identifiers: selectors, API validation, DB constraints, Zod/TS unions, project/assignment/submission types.

## 1. Copy files
- [ ] `src/lib/python/`, `src/app/api/python/`, `src/components/python/`, `src/types/css-modules.d.ts` (skip if you already declare CSS modules)
- [ ] `sandbox-worker/` to the sandbox host (not into the web build)
- [ ] `supabase/migrations/0012_*.sql`: rename if 0012 is already taken
- [ ] Confirm the `@/` import alias exists in your tsconfig

## 2. Wire auth + rate limit
- [ ] Edit `src/lib/python/pythonApiDeps.ts` (example in file). Until wired, the routes return 503.

## 3. Language registration
- [ ] Add `"python"` to your language union/enums and API validators (anything that rejects unknown languages)
- [ ] Language selector: add "Python 3" (keep the default unchanged)
- [ ] Editor: Monaco/CodeMirror `python` mode, starter from `pythonStarter.ts`, `.py` extension/default filename `main.py`
- [ ] Select the Python endpoints when language === `python`; mount `<PythonTracePanel>` (keep one hook instance per tab/project so state is isolated)
- [ ] Highlight the current line using `onActiveLine`
- [ ] Don't let language inference from file extension overwrite an explicitly stored language

## 4. Data
- [ ] Review/run the migration on a dev branch; widen reported constraints
- [ ] Map `curriculum/python-curriculum.json` to your lesson/question tables; idempotent upserts; hidden tests stay server-side
- [ ] Projects, assignments, submissions: persist `language = 'python'`; check RLS policies need no change (they usually key on ownership/membership, not language)

## 5. Verify
- [ ] `npm run test`, `npx tsc --noEmit`, `npm run build`
- [ ] Manual: run, syntax error, runtime error, stdin, trace + step back/forward, timeout, truncation notice, mobile width, keyboard-only navigation of the controls
- [ ] Regression: C++ run + GDB trace, Assembly lab, classrooms, projects, messaging, auth
- [ ] Sandbox: build image and run `run_security_checks.sh` on the sandbox VM
